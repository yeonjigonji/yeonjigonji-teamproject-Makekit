package org.zerock.service;

public interface SampleService {
	
	public Integer doAdd(String str1, String str2) throws Exception;
	
	
}
