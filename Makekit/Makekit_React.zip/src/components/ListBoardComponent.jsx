import React, { Component } from 'react';
import BoardService from '../service/BoardService';
import 'bootstrap/dist/css/bootstrap.css';
import dayjs from 'dayjs';


class ListBoardComponent extends Component {
    constructor(props) {
        super(props)

        this.state = { 
            boards: []
        }
      this.createBoard = this.createBoard.bind(this);
    }

    componentDidMount() {
        BoardService.getBoards().then((res) => {
            this.setState({ boards: res.data});
        });
    }

    createBoard() {
        this.props.history.push('/create-board/_create')
    }

    readBoard(bno) {
        this.props.history.push(`/read-board/${bno}`);
    }

    render() {
        return (
            <div>
                <h2 className="text-center">Q&A</h2>
                <div className = "row">
                    <button className="btn btn-primary" onClick={this.createBoard}> 글 작성</button>
                </div>
                <div className ="row">
                    <table className="table table-striped table-bordered">
                        <thead>
                            <tr>
                                <th>글 번호</th>
                                <th>글 제목 </th>
                                <th>작성자 </th>
                                <th>작성일 </th>                                
                            </tr>
                        </thead>
                        <tbody>
                            {
                                this.state.boards.map(
                                    board => 
                                    <tr key = {board.bno}>
                                        <td> {board.bno} </td>
                                        <td> <a onClick = {() => this.readBoard(board.bno)}>{board.title} </a></td>
                                        <td> {board.writer} </td>
                                        <td> {dayjs(board.regdate).format('YYYY-MM-DD HH:mm')} </td>                                                                                
                                    </tr>
                                )
                            }
                        </tbody>
                    </table>
                </div>
            </div>
        );
    }
}

export default ListBoardComponent;