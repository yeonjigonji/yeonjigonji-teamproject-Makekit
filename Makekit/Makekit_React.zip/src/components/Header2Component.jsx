import React, { Component } from 'react';
import 'bootstrap/dist/css/bootstrap.css';
import './Style.css'
import './Style2.css'

class Header2Component extends Component {
    constructor(props) {
        super(props)

        this.state = {

        }
    }
    render() {
        return (
            <>
                <nav className="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light">
                    <div className="container">
                        <a className="navbar-brand" href="http://192.168.0.126:9006/">MakeKit</a>
                        {/* <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation"> */}
                            {/* <span className="oi oi-menu"></span> Menu */}
                        {/* </button> */}

                        <div>
                            <ul className="navbar-nav ml-auto">
                                <li className="nav-item active"><a href="http://192.168.0.126:9006/" className="nav-link">홈</a></li>
                                <li className="nav-item"><a href="http://192.168.0.126:9006/shop" className="nav-link">Shop</a></li>
                                <li className="nav-item"><a href="http://192.168.0.126:9006/about" className="nav-link">About</a></li>
                                <li className="nav-item"><a href="http://192.168.0.126:9006/board/list" className="nav-link">Notice</a></li>
                                <li className="nav-item"><a href="http://192.168.0.126:9006/Eboard/elist" className="nav-link">Review</a></li>
                                <li className="nav-item"><a href="http://192.168.0.126:3000/" className="nav-link">Q & A</a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </>
        )
    }
}

export default Header2Component;