import React from "react";
import { Link } from "react-router-dom";

const ViewButtonQA = () => {
  return (
    <>
      <Link to="/Insert">
        <button> QA 게시글 등록</button>
      </Link>
      <Link to="/View">
        <button> QA 최근 게시글 보기</button>
      </Link>
      <Link to="/Update">
        <button> QA최근 게시글 수정</button>
      </Link>
      <Link to="/Delete">
        <button> QA최근 게시글 삭제</button>
      </Link>
    </>
  );
};

export default ViewButtonQA;