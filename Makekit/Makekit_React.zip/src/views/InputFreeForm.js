import axios from "axios";
import React, { Component } from "react";
import { Link } from "react-router-dom";

class InputFreeForm extends Component {
  constructor(props) {
    super(props);
    this.state = {
      bno: "",
      title: "",
      content: "",
      writer: "",
      crud: props.match.params.crud,
    };
    if (this.state.crud !== "Insert") {
      this.getData();
    }
  }

  createHeaderName() {
    const crud = this.state.crud;
    if (crud === "View") {
      return "조회";
    } else if (crud === "Update") {
      return "수정";
    } else if (crud === "Delete") {
      return "삭제";
    } else if (crud === "Insert") {
      return "등록";
    }
  }

  createCrudBtn() {
    const crud = this.state.crud;
    if (crud === "View") {
      return null;
    } else {
      const crudName =
      crud === "Update" ? "수정" : crud === "Insert" ? "등록" : "삭제";
      return (
        <button onClick={() => this.crud()}>게시글 {crudName}</button>
      );
    }
  }

  crud() {
    const { bno, title, content , writer, crud } = this.state;

    let crudType = "";

    if (crud === "Update") {
      crudType = "/updateFreeProcess.do";
    } else if (crud === "Delete") {
      crudType = "/deleteFreeProcess.do";
    } else if (crud === "Insert") {
      crudType = "/insertFreeProcess.do";
    } else if (crud === "View") {
      return null;
    }

    let form = new FormData();
    form.append("content", content)
    form.append("title", title);
    form.append("writer", writer);
    if (crud !== "Insert") {
      form.append("bno", bno);
    }

    axios
      .post(crudType, form)
      .then((res) => {
        alert("요청이 처리되었습니다");
        this.props.history.push("/");
      })
      .catch((err) => alert("error: " + err.response.data.msg));
  }

  getData() {
    axios.get("/viewFree.do").then((res) => {
      const data = res.data;
      this.setState({
        bno: data.bno,
        title: data.title,
        content: data.content,
        writer: data.writer
      });
    });
  }

  createbnoTag() {
    const bno = this.state.bno;
    const crud = this.state.crud;
    if (crud !== "Insert") {
      return <input type="hidden" value={bno} readOnly />;
    } else {
      return null;
    }
  }
  

  render() {
    const title = this.state.title;
    const content = this.state.content;
    const writer = this.state.writer;

    return (
      <>
        <h1>게시글 {this.createHeaderName()}</h1>
        {this.createbnoTag()}
        <h3>제목</h3>
        <input
          type="text"
          value={title}
          onChange={(event) =>
            this.setState({ title: event.target.value })
          }
        />
        <br />
        <h3>내용보여주기</h3>
        <textarea
          rows="10"
          cols="20"
          value={content}
          onChange={(event) =>
            this.setState({ content: event.target.value })
          }
        ></textarea>
        <br />
        <h3>작성자</h3>
        <input
          type="text"
          value={writer}
          onChange={(event) =>
            this.setState({ writer: event.target.value })
          }
        />
        <br /> <br />
        {this.createCrudBtn()}
        <Link to="/">
          <button type="button">취소</button>
        </Link>
      </>
    );
  }
}

export default InputFreeForm;