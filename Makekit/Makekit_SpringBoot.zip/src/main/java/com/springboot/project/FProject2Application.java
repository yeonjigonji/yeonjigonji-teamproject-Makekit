package com.springboot.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FProject2Application {

	public static void main(String[] args) {
		SpringApplication.run(FProject2Application.class, args);
	}

}
